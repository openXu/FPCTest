package com.fpc.test;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.fpc.test.net.NetActivity;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;


public class MainActivity extends AppCompatActivity {
    @BindView(R.id.btn_net)
    Button btnNet;


//    @BindView(R.id.btn_net)
//    Button btnNet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
//        Log.d(getClass().getSimpleName(), "btn_net=" + btnNet);
//        Unbinder uUnbinder = ButterKnife.bind(this);
//        Log.d(getClass().getSimpleName(), uUnbinder+"btn_net=" + btnNet);
        btnNet.setOnClickListener(v -> {
            startActivity(new Intent(this, NetActivity.class));
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
