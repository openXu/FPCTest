package com.fpc.test.net;

import android.os.Bundle;

import com.fpc.test.R;

import androidx.appcompat.app.AppCompatActivity;

public class NetActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
