package com.fpc;

public class TEst {

    private String a;
}
